import React, { useState } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import DatePicker from 'react-native-datepicker';
import { MaterialIcons } from '@expo/vector-icons';

const AgeCalculationScreen = () => {
  const [selectedDate, setSelectedDate] = useState(null);

  const calculateAge = () => {
    // Doğum tarihinden yaş bilgisini hesapla
    if (selectedDate) {
      const birthDate = new Date(selectedDate);
      const today = new Date();
      const yearsDiff = today.getFullYear() - birthDate.getFullYear();
      const monthsDiff = today.getMonth() - birthDate.getMonth();
      const daysDiff = today.getDate() - birthDate.getDate();

      // Yaş bilgilerini döndür
      return {
        years: yearsDiff,
        months: monthsDiff,
        days: daysDiff,
      };
    }

    return null;
  };

  const calculateNextBirthday = () => {
    // Doğum tarihinden bir sonraki doğum günü bilgisini hesapla
    if (selectedDate) {
      const birthDate = new Date(selectedDate);
      const today = new Date();

      const nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());

      if (nextBirthday < today) {
        nextBirthday.setFullYear(today.getFullYear() + 1);
      }

      const daysDiff = Math.ceil((nextBirthday - today) / (1000 * 60 * 60 * 24));

      // Doğum günü bilgisini döndür
      return {
        nextBirthday: nextBirthday.toLocaleDateString(),
        daysUntilBirthday: daysDiff,
      };
    }

    return null;
  };

  const age = calculateAge();
  const nextBirthday = calculateNextBirthday();

  return (
    <View style={styles.container}>
      <View style={styles.cardContainer}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Yaş</Text>
          {age && (
            <View style={styles.infoContainer}>
              <Text style={styles.infoText}>{age.years} Yıl</Text>
              <Text style={styles.infoText}>{age.months} Ay</Text>
            </View>
          )}
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Doğum Günü</Text>
          {nextBirthday && (
            <View style={styles.infoContainer}>
              <Text style={styles.infoText}>{nextBirthday.nextBirthday}</Text>
              <Text style={styles.infoText}>
                {nextBirthday.daysUntilBirthday} Gün Kaldı
              </Text>
            </View>
          )}
        </View>
      </View>
      <View style={styles.summaryCard}>
        <MaterialIcons name="cake" size={72} color="#6A00FF" />
        {age && (
          <View style={styles.summaryContainer}>
            <Text style={styles.summaryText}>{age.years} Yıl</Text>
            <Text style={styles.summaryText}>{age.months} Ay</Text>
            <Text style={styles.summaryText}>{age.days} Gün</Text>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  cardContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  card: {
    width: '48%',
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  infoContainer: {
    alignItems: 'center',
  },
  infoText: {
    fontSize: 16,
    marginBottom: 4,
  },
  summaryCard: {
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  summaryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
  },
  summaryText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginHorizontal: 8,
  },
});

export default AgeCalculationScreen;
