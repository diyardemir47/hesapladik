import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const VolumeCalculationScreen = () => {
  const [length, setLength] = useState('');
  const [width, setWidth] = useState('');
  const [height, setHeight] = useState('');
  const [volume, setVolume] = useState('');

  const calculateVolume = () => {
    const l = parseFloat(length);
    const w = parseFloat(width);
    const h = parseFloat(height);

    const volumeValue = l * w * h;
    setVolume(volumeValue.toString());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Hacim Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Uzunluk"
        keyboardType="numeric"
        value={length}
        onChangeText={setLength}
      />
      <TextInput
        style={styles.input}
        placeholder="Genişlik"
        keyboardType="numeric"
        value={width}
        onChangeText={setWidth}
      />
      <TextInput
        style={styles.input}
        placeholder="Yükseklik"
        keyboardType="numeric"
        value={height}
        onChangeText={setHeight}
      />
      <Button title="Hesapla" onPress={calculateVolume} />
      <Text style={styles.resultText}>Hacim: {volume}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  resultText: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default VolumeCalculationScreen;
