import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const Matematik = ({ navigation }) => {
   const handleTopicPress = (routeName) => {
    const calculation = topics
      .flatMap((category) => category.calculations)
      .find((calculation) => calculation.name === routeName);
    if (calculation && calculation.route) {
      navigation.navigate(calculation.route);
    }
  };

  const topics = [
    {
      category: '',
      calculations: [
        { name: 'Üslü Sayı Hesaplama', icon: 'ios-calculator-outline', route: 'Uslu_Sayi' },
        { name: 'Köklü Sayı Hesaplama', icon: 'ios-calculator-outline', route: 'RootCalculation' },
        { name: 'Yaş Hesaplama', icon: 'ios-hourglass-outline', route: 'AgeCalculation' },
        { name: 'Faktöriyel Hesaplama', icon: 'ios-calculator-outline', route: 'FactorialCalculation' },
        { name: 'Altın Oran Hesaplama', icon: 'ios-calculator-outline', route: 'AltinOranHesaplama' },
        { name: 'Kombinasyon Hesaplama', icon: 'ios-calculator-outline', route: 'KombinasyonHesaplama' },
        { name: 'Metrekare Hesaplama', icon: 'ios-calculator-outline', route: 'MetrekareHesaplama' },
        { name: 'Standart Sapma Hesaplama', icon: 'ios-calculator-outline', route: 'StandartSapmaHesaplama' },
        { name: 'Daire Hesaplama', icon: 'ios-calculator-outline', route: 'DaireHesaplama' },
        { name: 'Küp Hesaplama', icon: 'ios-calculator-outline', route: 'KupHesaplama' },
        { name: 'Küre Hesaplama', icon: 'ios-calculator-outline', route: 'KureHesaplama' },
      ],
    },
  ];


  return (
    <ScrollView contentContainerStyle={styles.container}>
      {topics.map((category) => (
        <View key={category.category} style={styles.categoryContainer}>
          <Text style={styles.categoryTitle}>{category.category}</Text>
          {category.calculations.map((calculation) => (
            <TouchableOpacity
              key={calculation.name}
              style={styles.button}
              onPress={() => handleTopicPress(calculation.name)}
            >
              <Ionicons name={calculation.icon} size={32} color="#6A00FF" />
              <Text style={styles.buttonText}>{calculation.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  categoryContainer: {
    marginBottom: 20,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginBottom: 10,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    elevation: 3,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
});

export default Matematik;
