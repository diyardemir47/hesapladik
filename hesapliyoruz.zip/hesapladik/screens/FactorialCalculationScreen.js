import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const FactorialCalculationScreen = () => {
  const [number, setNumber] = useState('');
  const [factorial, setFactorial] = useState('');

  const calculateFactorial = () => {
    const n = parseInt(number);

    if (n < 0) {
      setFactorial('Geçersiz sayı');
    } else if (n === 0) {
      setFactorial('1');
    } else {
      let result = 1;
      for (let i = 1; i <= n; i++) {
        result *= i;
      }
      setFactorial(result.toString());
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Faktöriyel Hesaplama</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Sayı"
          placeholderTextColor="#999"
          keyboardType="numeric"
          value={number}
          onChangeText={setNumber}
        />
        <Icon name="math-compass" style={styles.icon} />
      </View>
      <Button title="Hesapla" onPress={calculateFactorial} color="#9c27b0" />
      {factorial !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>Sonuç: {factorial}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
    marginRight: 10,
  },
  icon: {
    fontSize: 24,
    color: '#999',
  },
  resultContainer: {
    width: '100%',
    padding: 16,
    marginTop: 20,
    borderRadius: 8,
    backgroundColor: '#9c27b0',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
});

export default FactorialCalculationScreen;
