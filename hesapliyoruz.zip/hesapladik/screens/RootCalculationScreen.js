import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import Card from '../components/Card';
import { IconButton } from "@react-native-material/core";
import Icon from "@expo/vector-icons/MaterialCommunityIcons";

const RootCalculationScreen = () => {
  const [number, setNumber] = useState('');
  const [result, setResult] = useState('');

  const calculateSquareRoot = () => {
    const numberValue = parseFloat(number);
    const squareRootResult = Math.sqrt(numberValue);
    setResult(squareRootResult.toString());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Köklü Sayılar Hesaplama</Text>
      <Card>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="√ Sayı"
            value={number}
            onChangeText={(text) => setNumber(text)}
            keyboardType="numeric"
          />
          <IconButton
            icon={(props) => <Icon name="square-root" {...props} />}
            style={styles.iconButton}
            onPress={calculateSquareRoot}
          />
        </View>
        <Button title="Hesapla" onPress={calculateSquareRoot} />
        <Text style={styles.result}>{result}</Text>
      </Card>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  iconButton: {
    marginLeft: 10,
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
  },
});

export default RootCalculationScreen;
