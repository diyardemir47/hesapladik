import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import DatePicker from 'react-native-datepicker';

const DateDifferenceScreen = () => {
  const [selectedDate1, setSelectedDate1] = useState(null);
  const [selectedDate2, setSelectedDate2] = useState(null);
  const [difference, setDifference] = useState(null);

  const calculateDifference = () => {
    if (selectedDate1 && selectedDate2) {
      const date1 = new Date(selectedDate1);
      const date2 = new Date(selectedDate2);
      const differenceInTime = date2.getTime() - date1.getTime();
      const differenceInDays = Math.floor(
        differenceInTime / (1000 * 3600 * 24)
      );
      setDifference(differenceInDays);
    } else {
      setDifference(null);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Verilen Tarihler Arasında Kaç Gün Var?</Text>
      <DatePicker
        style={styles.datePickerButton}
        date={selectedDate1}
        mode="date"
        placeholder="Tarih Seç"
        format="YYYY-MM-DD"
        confirmBtnText="Seç"
        cancelBtnText="İptal"
        onDateChange={(date) => setSelectedDate1(date)}
      />
      <DatePicker
        style={styles.datePickerButton}
        date={selectedDate2}
        mode="date"
        placeholder="Tarih Seç"
        format="YYYY-MM-DD"
        confirmBtnText="Seç"
        cancelBtnText="İptal"
        onDateChange={(date) => setSelectedDate2(date)}
      />
      <TouchableOpacity
        style={styles.calculateButton}
        onPress={calculateDifference}>
        <Text style={styles.calculateButtonText}>Hesapla</Text>
      </TouchableOpacity>
      {difference !== null && (
        <Text style={styles.result}>
          Seçilen tarihler arasında {difference} gün var.
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  datePickerButton: {
    backgroundColor: '#e0e0e0',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginBottom: 10,
    width: '80%',
  },
  calculateButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginTop: 10,
    width: '80%',
  },
  calculateButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  result: {
    fontSize: 18,
    marginTop: 20,
    textAlign: 'center',
  },
});

export default DateDifferenceScreen;
