import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, StatusBar } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#6A00FF" />
      
      <TouchableOpacity
        style={[styles.card, { backgroundColor: '#FF4081' }]}
        onPress={() => navigation.navigate('Matematik')}
      >
        <Text style={styles.cardIcon}>✚</Text>
        <Text style={styles.cardTitle}>Matematik Hesaplamaları</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card, { backgroundColor: '#536DFE' }]}
        onPress={() => navigation.navigate('Saglik')}
      >
        <Text style={styles.cardIcon}>❤️</Text>
        <Text style={styles.cardTitle}>Sağlık Hesaplamaları</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card, { backgroundColor: '#00BFA5' }]}
        onPress={() => navigation.navigate('Zaman')}
      >
        <Text style={styles.cardIcon}>⌛</Text>
        <Text style={styles.cardTitle}>Zaman Hesaplamaları</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card, { backgroundColor: '#FF9100' }]}
        onPress={() => navigation.navigate('Egitim')}
      >
        <Text style={styles.cardIcon}>🎓</Text>
        <Text style={styles.cardTitle}>Eğitim Hesaplamaları</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card, { backgroundColor: '#64DD17' }]}
        onPress={() => navigation.navigate('Finans')}
      >
        <Text style={styles.cardIcon}>💰</Text>
        <Text style={styles.cardTitle}>Finans Hesaplamaları</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card, { backgroundColor: '#FF5722' }]}
        onPress={() => navigation.navigate('Karma')}
      >
        <Text style={styles.cardIcon}>🔄</Text>
        <Text style={styles.cardTitle}>Karma Hesaplamalar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
    backgroundColor: '#F5F5F5',
  },
  card: {
    width: 300,
    height: 150,
    borderRadius: 8,
    marginBottom: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  cardIcon: {
    fontSize: 50,
    marginBottom: 10,
    color: 'white',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
});

export default HomeScreen;
