import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const CalculationScreen = ({ navigation }) => {
  const handleTopicPress = (routeName) => {
    navigation.navigate(routeName);
  };

  const topics = [
    {
      category: 'Matematik',
      calculations: [
        { name: 'Power', icon: 'ios-calculator-outline' },
        { name: 'RootCalculation', icon: 'ios-square-root-outline' },
        { name: 'AgeCalculation', icon: 'ios-hourglass-outline' },
        { name: 'FactorialCalculation', icon: 'ios-calculator-outline' },
        { name: 'VolumeCalculation', icon: 'ios-calculator-outline' },
         { name: 'AltinOranHesaplama', icon: 'ios-calculator-outline' }
      ],
    },
    {
      category: 'Sağlık',
      calculations: [
        { name: 'BmiCalculation', icon: 'ios-body-outline' },
        { name: 'WaterFatCalculation', icon: 'ios-water-outline' },
      ],
    },
    {
      category: 'Zaman',
      calculations: [
        { name: 'BirthdayCountdown', icon: 'ios-calendar-outline' },
        { name: 'NewYearCountdown', icon: 'ios-calendar-outline' },
        { name: 'Holiday', icon: 'ios-calendar-outline' },
        { name: 'DateDifference', icon: 'ios-calendar-outline' },
      ],
    },
    {
      category: 'Eğitim',
      calculations: [
        { name: 'CreditCalculation', icon: 'ios-card-outline' },
        { name: 'GoldCalculation', icon: 'ios-trophy-outline' },
        { name: 'DollarCalculation', icon: 'ios-cash-outline' },
        { name: 'Vize-Final Not Ortalama', icon: 'ios-calculator-outline' },
        { name: 'Takdir-Teşekkür', icon: 'ios-ribbon-outline' },
      ],
    },
  ];

  return (
    <View style={styles.container}>
      {topics.map((category) => (
        <View key={category.category} style={styles.categoryContainer}>
          <Text style={styles.categoryTitle}>{category.category}</Text>
          {category.calculations.map((calculation) => (
            <TouchableOpacity
              key={calculation.name}
              style={styles.button}
              onPress={() => handleTopicPress(calculation.name)}
            >
              <Ionicons name={calculation.icon} size={32} color="#6A00FF" />
              <Text style={styles.buttonText}>{calculation.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  categoryContainer: {
    marginBottom: 20,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginBottom: 10,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    elevation: 3,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
});

export default CalculationScreen;
