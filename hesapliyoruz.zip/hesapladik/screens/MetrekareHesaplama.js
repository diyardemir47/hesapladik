// SquareAreaCalc.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const MetrekareHesaplama = () => {
  const [inputValue, setInputValue] = useState('');
  const [result, setResult] = useState('');

  const calculateSquareArea = () => {
    if (inputValue === '') {
      setResult('Lütfen bir değer girin.');
      return;
    }

    const side = parseFloat(inputValue);

    if (isNaN(side) || side <= 0) {
      setResult('Geçerli bir sayı girin.');
      return;
    }

    const area = side * side;

    setResult(`Kare Alanı: ${area}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Metrekare Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Bir değer girin"
        keyboardType="numeric"
        value={inputValue}
        onChangeText={text => setInputValue(text)}
      />
      <TouchableOpacity style={styles.button} onPress={calculateSquareArea}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>
      <Text style={styles.result}>{result}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default MetrekareHesaplama;
