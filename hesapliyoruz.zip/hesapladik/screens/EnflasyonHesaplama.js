import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, Picker } from 'react-native';

const EnflasyonHesaplama = () => {
  const [malSepetiTutari, setMalSepetiTutari] = useState('');
  const [secilenDonem, setSecilenDonem] = useState('');
  const [enflasyonOrani, setEnflasyonOrani] = useState('');

  const donemler = [
  { label: 'Kasım 2015', value: 100, tufe: 592.19, enflasyonOrani: 0.96 },
  { label: 'Aralık 2015', value: 99, tufe: 596.68, enflasyonOrani: 0.70 },
  { label: 'Ocak 2016', value: 98, tufe: 601.89, enflasyonOrani: 0.82 },
  { label: 'Şubat 2016', value: 97, tufe: 606.04, enflasyonOrani: 0.81 },
  { label: 'Mart 2016', value: 96, tufe: 608.94, enflasyonOrani: 0.43 },
  { label: 'Nisan 2016', value: 95, tufe: 616.90, enflasyonOrani: 1.38 },
  { label: 'Mayıs 2016', value: 94, tufe: 619.48, enflasyonOrani: 0.50 },
  { label: 'Haziran 2016', value: 93, tufe: 621.68, enflasyonOrani: 0.34 },
  { label: 'Temmuz 2016', value: 92, tufe: 626.70, enflasyonOrani: 0.80 },
  { label: 'Ağustos 2016', value: 91, tufe: 627.72, enflasyonOrani: 0.16 },
  { label: 'Eylül 2016', value: 90, tufe: 628.77, enflasyonOrani: 0.18 },
  { label: 'Ekim 2016', value: 89, tufe: 637.40, enflasyonOrani: 1.44 },
  { label: 'Kasım 2016', value: 88, tufe: 641.43, enflasyonOrani: 0.66 },
  { label: 'Aralık 2016', value: 87, tufe: 646.54, enflasyonOrani: 0.72 },
  { label: 'Ocak 2017', value: 86, tufe: 657.19, enflasyonOrani: 1.72 },
  { label: 'Şubat 2017', value: 85, tufe: 662.58, enflasyonOrani: 0.81 },
  { label: 'Mart 2017', value: 84, tufe: 668.95, enflasyonOrani: 0.99 },
  { label: 'Nisan 2017', value: 83, tufe: 677.04, enflasyonOrani: 1.31 },
  { label: 'Mayıs 2017', value: 82, tufe: 680.61, enflasyonOrani: 0.45 },
  { label: 'Haziran 2017', value: 81, tufe: 682.02, enflasyonOrani: 0.27 },
  { label: 'Temmuz 2017', value: 80, tufe: 686.41, enflasyonOrani: 0.65 },
  { label: 'Ağustos 2017', value: 79, tufe: 688.46, enflasyonOrani: 0.30 },
  { label: 'Eylül 2017', value: 78, tufe: 698.03, enflasyonOrani: 1.39 },
  { label: 'Ekim 2017', value: 77, tufe: 709.73, enflasyonOrani: 1.68 },
  { label: 'Kasım 2017', value: 76, tufe: 721.03, enflasyonOrani: 1.60 },
  { label: 'Aralık 2017', value: 75, tufe: 743.27, enflasyonOrani: 3.09 },
  { label: 'Ocak 2018', value: 74, tufe: 763.81, enflasyonOrani: 2.76 },
  { label: 'Şubat 2018', value: 73, tufe: 768.30, enflasyonOrani: 0.59 },
  { label: 'Mart 2018', value: 72, tufe: 774.32, enflasyonOrani: 0.78 },
  { label: 'Nisan 2018', value: 71, tufe: 788.73, enflasyonOrani: 1.86 },
  { label: 'Mayıs 2018', value: 70, tufe: 797.29, enflasyonOrani: 1.09 },
  { label: 'Haziran 2018', value: 69, tufe: 799.95, enflasyonOrani: 0.34 },
  { label: 'Temmuz 2018', value: 68, tufe: 816.07, enflasyonOrani: 2.02 },
  { label: 'Ağustos 2018', value: 67, tufe: 840.33, enflasyonOrani: 2.97 },
  { label: 'Eylül 2018', value: 66, tufe: 861.63, enflasyonOrani: 2.53 },
  { label: 'Ekim 2018', value: 65, tufe: 875.44, enflasyonOrani: 1.60 },
  { label: 'Kasım 2018', value: 64, tufe: 884.44, enflasyonOrani: 1.03 },
  { label: 'Aralık 2018', value: 63, tufe: 885.75, enflasyonOrani: 0.15 },
  { label: 'Ocak 2019', value: 62, tufe: 905.87, enflasyonOrani: 2.27 },
  { label: 'Şubat 2019', value: 61, tufe: 908.65, enflasyonOrani: 0.31 },
  { label: 'Mart 2019', value: 60, tufe: 913.82, enflasyonOrani: 0.57 },
  { label: 'Nisan 2019', value: 59, tufe: 929.69, enflasyonOrani: 1.74 },
  { label: 'Mayıs 2019', value: 58, tufe: 936.30, enflasyonOrani: 0.71 },
  { label: 'Haziran 2019', value: 57, tufe: 940.96, enflasyonOrani: 0.50 },
  { label: 'Temmuz 2019', value: 56, tufe: 949.39, enflasyonOrani: 0.90 },
  { label: 'Ağustos 2019', value: 55, tufe: 956.01, enflasyonOrani: 0.70 },
  { label: 'Eylül 2019', value: 54, tufe: 963.02, enflasyonOrani: 0.73 },
  { label: 'Ekim 2019', value: 53, tufe: 978.76, enflasyonOrani: 1.63 },
  { label: 'Kasım 2019', value: 52, tufe: 994.48, enflasyonOrani: 1.60 },
  { label: 'Aralık 2019', value: 51, tufe: 1018.95, enflasyonOrani: 2.47 },
  { label: 'Ocak 2020', value: 50, tufe: 1028.65, enflasyonOrani: 0.95 },
  { label: 'Şubat 2020', value: 49, tufe: 1036.69, enflasyonOrani: 0.78 },
  { label: 'Mart 2020', value: 48, tufe: 1043.41, enflasyonOrani: 0.65 },
  { label: 'Nisan 2020', value: 47, tufe: 1066.14, enflasyonOrani: 2.18 },
  { label: 'Mayıs 2020', value: 46, tufe: 1076.54, enflasyonOrani: 0.98 },
  { label: 'Haziran 2020', value: 45, tufe: 1086.43, enflasyonOrani: 0.92 },
  { label: 'Temmuz 2020', value: 44, tufe: 1102.18, enflasyonOrani: 1.45 },
  { label: 'Ağustos 2020', value: 43, tufe: 1131.55, enflasyonOrani: 2.66 },
  { label: 'Eylül 2020', value: 42, tufe: 1151.19, enflasyonOrani: 1.73 },
  { label: 'Ekim 2020', value: 41, tufe: 1184.45, enflasyonOrani: 2.89 },
  { label: 'Kasım 2020', value: 40, tufe: 1199.10, enflasyonOrani: 1.24 },
  { label: 'Aralık 2020', value: 39, tufe: 1227.89, enflasyonOrani: 2.40 },
  { label: 'Ocak 2021', value: 38, tufe: 1256.65, enflasyonOrani: 2.35 },
  { label: 'Şubat 2021', value: 37, tufe: 1285.78, enflasyonOrani: 2.32 },
  { label: 'Mart 2021', value: 36, tufe: 1311.05, enflasyonOrani: 1.96 },
  { label: 'Nisan 2021', value: 35, tufe: 1344.08, enflasyonOrani: 2.52 },
  { label: 'Mayıs 2021', value: 34, tufe: 1391.57, enflasyonOrani: 3.53 },
  { label: 'Haziran 2021', value: 33, tufe: 1414.93, enflasyonOrani: 1.68 },
  { label: 'Temmuz 2021', value: 32, tufe: 1442.35, enflasyonOrani: 1.94 },
  { label: 'Ağustos 2021', value: 31, tufe: 1482.64, enflasyonOrani: 2.80 },
  { label: 'Eylül 2021', value: 30, tufe: 1507.90, enflasyonOrani: 1.70 },
  { label: 'Ekim 2021', value: 29, tufe: 1557.79, enflasyonOrani: 3.31 },
  { label: 'Kasım 2021', value: 28, tufe: 1610.08, enflasyonOrani: 3.36 },
  { label: 'Aralık 2021', value: 27, tufe: 1657.86, enflasyonOrani: 2.98 },
  { label: 'Ocak 2022', value: 26, tufe: 1716.30, enflasyonOrani: 3.54 },
  { label: 'Şubat 2022', value: 25, tufe: 1776.72, enflasyonOrani: 3.52 },
  { label: 'Mart 2022', value: 24, tufe: 1825.27, enflasyonOrani: 2.73 },
  { label: 'Nisan 2022', value: 23, tufe: 1892.74, enflasyonOrani: 3.69 },
  { label: 'Mayıs 2022', value: 22, tufe: 1978.18, enflasyonOrani: 4.52 },
  { label: 'Haziran 2022', value: 21, tufe: 2034.09, enflasyonOrani: 2.82 },
  { label: 'Temmuz 2022', value: 20, tufe: 2125.19, enflasyonOrani: 4.48 },
  { label: 'Ağustos 2022', value: 19, tufe: 2236.16, enflasyonOrani: 5.26 },
  { label: 'Eylül 2022', value: 18, tufe: 2339.71, enflasyonOrani: 4.66 },
  { label: 'Ekim 2022', value: 17, tufe: 2441.66, enflasyonOrani: 4.28 },
  { label: 'Kasım 2022', value: 16, tufe: 2551.90, enflasyonOrani: 4.52 },
  { label: 'Aralık 2022', value: 15, tufe: 2662.04, enflasyonOrani: 4.34 },
  { label: 'Ocak 2023', value: 14, tufe: 2785.32, enflasyonOrani: 4.64 },
  { label: 'Şubat 2023', value: 13, tufe: 2908.09, enflasyonOrani: 4.40 },
  { label: 'Mart 2023', value: 12, tufe: 3035.24, enflasyonOrani: 4.37 },
  { label: 'Nisan 2023', value: 11, tufe: 3172.42, enflasyonOrani: 4.50 },
  { label: 'Mayıs 2023', value: 10, tufe: 3312.12, enflasyonOrani: 4.42 }
];

  const calculateEnflasyonOrani = () => {
    if (malSepetiTutari === '' || secilenDonem === '') {
      setEnflasyonOrani('Lütfen tüm alanları doldurun.');
      return;
    }

    const malSepetiTutariNum = parseFloat(malSepetiTutari.replace(',', '.'));
    const secilenDonemNum = parseInt(secilenDonem);

    if (isNaN(malSepetiTutariNum) || isNaN(secilenDonemNum)) {
      setEnflasyonOrani('Geçerli değerler girin.');
      return;
    }

    const enflasyonOraniNum = donemler[secilenDonemNum].enflasyonOrani;
    const enflasyonluTutar = malSepetiTutariNum * (1 + enflasyonOraniNum / 100);

    setEnflasyonOrani(`Enflasyon Oranı: ${enflasyonOraniNum.toFixed(2)}%\nEnflasyonlu Tutar: ${enflasyonluTutar.toFixed(2)}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enflasyon Hesaplama</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Mal Sepeti Tutarı:</Text>
        <TextInput
          style={styles.input}
          placeholder="Mal Sepeti Tutarını girin"
          keyboardType="numeric"
          value={malSepetiTutari}
          onChangeText={(text) => setMalSepetiTutari(text)}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Dönem Seçin:</Text>
        <Picker
          style={styles.picker}
          selectedValue={secilenDonem}
          onValueChange={(itemValue) => setSecilenDonem(itemValue)}
        >
          <Picker.Item label="Dönem Seçin" value="" />
          {donemler.map((donem) => (
            <Picker.Item key={donem.value} label={donem.label} value={donem.value} />
          ))}
        </Picker>
      </View>

      <TouchableOpacity style={styles.button} onPress={calculateEnflasyonOrani}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>

      {enflasyonOrani !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>{enflasyonOrani}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  picker: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#6A00FF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 20,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#6A00FF',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
});

export default EnflasyonHesaplama;
