import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

const KpssPuanHesaplama = () => {
  const [genelYetenekDogru, setGenelYetenekDogru] = useState('');
  const [genelYetenekYanlis, setGenelYetenekYanlis] = useState('');
  const [genelKulturDogru, setGenelKulturDogru] = useState('');
  const [genelKulturYanlis, setGenelKulturYanlis] = useState('');
  const [netDogru, setNetDogru] = useState(0);
  const [kpssPuan, setKpssPuan] = useState(0);

  const handleHesapla = () => {
    const genelYetenekD = parseInt(genelYetenekDogru);
    const genelYetenekY = parseInt(genelYetenekYanlis);
    const genelKulturD = parseInt(genelKulturDogru);
    const genelKulturY = parseInt(genelKulturYanlis);

    const netDogruSayisi = (genelYetenekD - genelYetenekY / 4) * 0.7 + (genelKulturD - genelKulturY / 4) * 0.3;
    const puan = netDogruSayisi + 40;

    setNetDogru(netDogruSayisi);
    setKpssPuan(puan);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>
        <Icon name="check" style={styles.icon} /> Genel Yetenek Doğru Cevap Sayısı:
      </Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={genelYetenekDogru}
        onChangeText={setGenelYetenekDogru}
      />

      <Text style={styles.label}>
        <Icon name="times" style={styles.icon} /> Genel Yetenek Yanlış Cevap Sayısı:
      </Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={genelYetenekYanlis}
        onChangeText={setGenelYetenekYanlis}
      />

      <Text style={styles.label}>
        <Icon name="check" style={styles.icon} /> Genel Kültür Doğru Cevap Sayısı:
      </Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={genelKulturDogru}
        onChangeText={setGenelKulturDogru}
      />

      <Text style={styles.label}>
        <Icon name="times" style={styles.icon} /> Genel Kültür Yanlış Cevap Sayısı:
      </Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={genelKulturYanlis}
        onChangeText={setGenelKulturYanlis}
      />

      <TouchableOpacity style={styles.button} onPress={handleHesapla}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>

      <Text style={styles.resultText}>Net Doğru Sayısı: {netDogru}</Text>
      <Text style={styles.resultText}>
        KPSS Puanı: {kpssPuan} - {kpssPuan >= 60 ? 'Geçtiniz!' : 'Geçemediniz!'}
      </Text>

      {kpssPuan >= 60 && (
        <View style={styles.suggestionContainer}>
          <Text style={styles.suggestionTitle}>Öneriler:</Text>
          <Text style={styles.suggestionText}>
            - Devam edin, başarılarınızı daha da artırmak için çalışmaya devam edin.
          </Text>
          <Text style={styles.suggestionText}>
            - Diğer sınavlara da hazırlanarak farklı kariyer fırsatlarını değerlendirin.
          </Text>
          <Text style={styles.suggestionText}>
            - İleri düzeydeki konulara yoğunlaşarak daha yüksek puanlar almayı hedefleyin.
          </Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 5,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  resultText: {
    fontSize: 16,
    marginTop: 10,
  },
  suggestionContainer: {
    marginTop: 20,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderRadius: 5,
    borderColor: 'green',
  },
  suggestionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  suggestionText: {
    fontSize: 14,
    marginBottom: 3,
  },
});

export default KpssPuanHesaplama;
