import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';

const FatBurnHeartRateCalculator = () => {
  const [restingHeartRate, setRestingHeartRate] = useState('');
  const [age, setAge] = useState('');
  const [fatBurnRange, setFatBurnRange] = useState('');

  const calculateFatBurnRange = () => {
    if (restingHeartRate === '' || age === '') {
      setFatBurnRange('Lütfen dinlenik nabzınızı ve yaşınızı girin.');
      return;
    }

    const restingHeartRateNum = parseFloat(restingHeartRate);
    const ageNum = parseFloat(age);

    if (isNaN(restingHeartRateNum) || isNaN(ageNum) || restingHeartRateNum <= 0 || ageNum <= 0) {
      setFatBurnRange('Geçerli değerler girin.');
      return;
    }

    // Karvonen formülüne göre hedef nabız aralığının hesaplanması
    const maxHeartRate = 220 - ageNum;
    const targetHeartRate = restingHeartRateNum + (0.6 * (maxHeartRate - restingHeartRateNum));
    const fatBurnLower = targetHeartRate - 10;
    const fatBurnUpper = targetHeartRate + 10;

    setFatBurnRange(`İdeal Yağ Yakım Aralığı: ${fatBurnLower.toFixed(0)} - ${fatBurnUpper.toFixed(0)} nabız/dk`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Yağ Yakım Nabız Aralığı Hesaplama</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Dinlenik Nabız:</Text>
        <TextInput
          style={styles.input}
          placeholder="Dinlenik nabzınızı girin"
          keyboardType="numeric"
          value={restingHeartRate}
          onChangeText={(text) => setRestingHeartRate(text)}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Yaşınız:</Text>
        <TextInput
          style={styles.input}
          placeholder="Yaşınızı girin"
          keyboardType="numeric"
          value={age}
          onChangeText={(text) => setAge(text)}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={calculateFatBurnRange}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>

      {fatBurnRange !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>{fatBurnRange}</Text>
        </View>
      )}

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Not: Bu hesaplama sadece bir tahmindir. Kişisel ihtiyaçlarınıza göre daha kesin bir hesaplama yapmak için
          beslenme uzmanıyla görüşün.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  label: {
    flex: 1,
    fontSize: 16,
  },
  input: {
    flex: 2,
    width: '100%',
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultContainer: {
    marginTop: 20,
    backgroundColor: 'lightgray',
    padding: 10,
    borderRadius: 5,
  },
  resultText: {
    fontSize: 16,
  },
  footer: {
    marginTop: 20,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    textAlign: 'center',
  },
});

export default FatBurnHeartRateCalculator;
