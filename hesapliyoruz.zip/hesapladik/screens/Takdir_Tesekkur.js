import React, { useState } from 'react';
import { View, Text, TextInput, Button, TouchableOpacity, StyleSheet } from 'react-native';

const Takdir_Tesekkur = () => {
  const [grades, setGrades] = useState([]);

  const addGrade = () => {
    setGrades([...grades, '']);
  };

  const updateGrade = (index, value) => {
    const newGrades = [...grades];
    newGrades[index] = value;
    setGrades(newGrades);
  };

  const removeGrade = (index) => {
    const newGrades = [...grades];
    newGrades.splice(index, 1);
    setGrades(newGrades);
  };

  const calculateResult = () => {
    let averageScore = 0;
    const numericGrades = grades.map((grade) => parseFloat(grade));
    if (numericGrades.length > 0) {
      averageScore = numericGrades.reduce((sum, grade) => sum + grade, 0) / numericGrades.length;
    }

    let result = '';
    let resultColor = '';

    if (isNaN(averageScore)) {
      result = '';
      resultColor = '';
    } else if (averageScore >= 85) {
      result = 'Takdir';
      resultColor = '#ff9800';
    } else if (averageScore >= 70) {
      result = 'Teşekkür';
      resultColor = '#4caf50';
    } else {
      result = 'Başarısız';
      resultColor = '#f44336';
    }

    setResult(result);
    setResultColor(resultColor);
    setAverageScore(averageScore);
  };

  const renderGradeInputs = () => {
    return grades.map((grade, index) => (
      <View style={styles.inputContainer} key={index}>
        <TextInput
          style={styles.input}
          placeholder={`Ders ${index + 1}`}
          keyboardType="numeric"
          value={grade}
          onChangeText={(value) => updateGrade(index, value)}
        />
        <TouchableOpacity style={styles.removeButton} onPress={() => removeGrade(index)}>
          <Text style={styles.removeButtonText}>X</Text>
        </TouchableOpacity>
      </View>
    ));
  };

  const [result, setResult] = useState('');
  const [resultColor, setResultColor] = useState('');
  const [averageScore, setAverageScore] = useState(0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Okul Takdir Teşekkür Hesaplama</Text>
      {renderGradeInputs()}
      <TouchableOpacity style={[styles.addButton, { backgroundColor: '#9c27b0' }]} onPress={addGrade}>
        <Text style={styles.addButtonText}>Ders Ekle</Text>
      </TouchableOpacity>
      <Button title="Hesapla" onPress={calculateResult} color="#9c27b0" />
      {result !== '' && (
        <View style={[styles.resultContainer, { backgroundColor: resultColor }]}>
          <Text style={styles.resultText}>Sonuç: {result}</Text>
          <Text style={styles.averageText}>Ortalama: {isNaN(averageScore) ? '-' : averageScore.toFixed(2)}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
    marginRight: 10,
  },
  addButton: {
    backgroundColor: '#9c27b0',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  removeButton: {
    backgroundColor: 'red',
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  removeButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  resultContainer: {
    width: '100%',
    padding: 16,
    marginTop: 20,
    borderRadius: 8,
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  averageText: {
    fontSize: 16,
    color: '#fff',
    marginTop: 8,
  },
});

export default Takdir_Tesekkur;
