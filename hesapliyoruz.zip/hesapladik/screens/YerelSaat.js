import React, { useState } from 'react';
import { View, Text, StyleSheet, Picker } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

const cities = [
  { name: 'Adana', longitude: 35.3242 },
  { name: 'Adıyaman', longitude: 38.2786 },
  { name: 'Afyonkarahisar', longitude: 30.5569 },
  { name: 'Ağrı', longitude: 43.0513 },
  { name: 'Amasya', longitude: 35.8353 },
  { name: 'Ankara', longitude: 32.8644 },
  { name: 'Antalya', longitude: 30.7133 },
  { name: 'Artvin', longitude: 41.1828 },
  { name: 'Aydın', longitude: 27.8420 },
  { name: 'Balıkesir', longitude: 27.8359 },
  { name: 'Bilecik', longitude: 29.9792 },
  { name: 'Bingöl', longitude: 40.4870 },
  { name: 'Bitlis', longitude: 42.1167 },
  { name: 'Bolu', longitude: 31.6069 },
  { name: 'Burdur', longitude: 30.2839 },
  { name: 'Bursa', longitude: 29.0634 },
  { name: 'Çanakkale', longitude: 26.4142 },
  { name: 'Çankırı', longitude: 33.6014 },
  { name: 'Çorum', longitude: 34.9513 },
  { name: 'Denizli', longitude: 29.0548 },
  { name: 'Diyarbakır', longitude: 40.2189 },
  { name: 'Edirne', longitude: 26.5587 },
  { name: 'Elazığ', longitude: 39.3099 },
  { name: 'Erzincan', longitude: 39.7361 },
  { name: 'Erzurum', longitude: 41.2679 },
  { name: 'Eskişehir', longitude: 30.5529 },
  { name: 'Gaziantep', longitude: 37.3833 },
  { name: 'Giresun', longitude: 38.3895 },
  { name: 'Gümüşhane', longitude: 39.4800 },
  { name: 'Hakkâri', longitude: 43.7198 },
  { name: 'Hatay', longitude: 36.2031 },
  { name: 'Isparta', longitude: 30.5303 },
  { name: 'Mersin', longitude: 34.6407 },
  { name: 'İstanbul', longitude: 28.9784 },
  { name: 'İzmir', longitude: 27.1428 },
  { name: 'Kars', longitude: 40.6066 },
  { name: 'Kastamonu', longitude: 33.3915 },
  { name: 'Kayseri', longitude: 35.4944 },
  { name: 'Kırklareli', longitude: 27.2287 },
  { name: 'Kırşehir', longitude: 33.2346 },
  { name: 'Kocaeli', longitude: 29.9403 },
  { name: 'Konya', longitude: 32.4920 },
  { name: 'Kütahya', longitude: 29.9327 },
  { name: 'Malatya', longitude: 38.3377 },
  { name: 'Manisa', longitude: 27.4178 },
  { name: 'Kahramanmaraş', longitude: 37.5917 },
  { name: 'Mardin', longitude: 40.7487 },
  { name: 'Muğla', longitude: 28.3636 },
  { name: 'Muş', longitude: 41.7548 },
  { name: 'Nevşehir', longitude: 34.6857 },
  { name: 'Niğde', longitude: 34.6716 },
  { name: 'Ordu', longitude: 37.8764 },
  { name: 'Rize', longitude: 40.5234 },
  { name: 'Sakarya', longitude: 30.5950 },
  { name: 'Samsun', longitude: 36.3313 },
  { name: 'Siirt', longitude: 41.9456 },
  { name: 'Sinop', longitude: 35.3292 },
  { name: 'Sivas', longitude: 37.0199 },
  { name: 'Tekirdağ', longitude: 27.5078 },
  { name: 'Tokat', longitude: 36.5547 },
  { name: 'Trabzon', longitude: 39.7263 },
  { name: 'Tunceli', longitude: 39.3439 },
  { name: 'Şanlıurfa', longitude: 38.4192 },
  { name: 'Uşak', longitude: 29.9953 },
  { name: 'Van', longitude: 38.5010 },
  { name: 'Yozgat', longitude: 34.7394 },
  { name: 'Zonguldak', longitude: 31.8414 },
  { name: 'Aksaray', longitude: 34.0224 },
  { name: 'Bayburt', longitude: 40.2280 },
  { name: 'Karaman', longitude: 33.2150 },
  { name: 'Kırıkkale', longitude: 33.4500 },
  { name: 'Batman', longitude: 41.1389 },
  { name: 'Şırnak', longitude: 42.4562 },
  { name: 'Bartın', longitude: 32.3375 },
  { name: 'Ardahan', longitude: 42.7022 },
  { name: 'Iğdır', longitude: 44.0433 },
  { name: 'Yalova', longitude: 29.2788 },
  { name: 'Karabük', longitude: 32.6226 },
  { name: 'Kilis', longitude: 37.1194 },
  { name: 'Osmaniye', longitude: 36.2478 },
  { name: 'Düzce', longitude: 31.1625 },
];


const LocalTimeScreen = () => {
  const [selectedCity, setSelectedCity] = useState('');

  const calculateLocalTime = () => {
    const selectedCityData = cities.find((city) => city.name === selectedCity);
    if (selectedCityData) {
      const meridianDifference = selectedCityData.longitude - 26; // Türkiye'nin batı boylamı 26°
      const timeDifference = Math.round(meridianDifference * 4);
      const hours = Math.floor(timeDifference / 60);
      const minutes = timeDifference % 60;
      const localTime = new Date();
      localTime.setHours(localTime.getHours() + hours);
      localTime.setMinutes(localTime.getMinutes() + minutes);
      return localTime.toLocaleTimeString();
    }
    return '';
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Yerel Saat Hesaplama</Text>
      <View style={styles.pickerContainer}>
        <Icon name="clock-o" style={styles.icon} />
        <Picker
          selectedValue={selectedCity}
          onValueChange={(itemValue) => setSelectedCity(itemValue)}
          style={styles.picker}
          itemStyle={styles.pickerItem}
        >
          <Picker.Item label="Şehir Seçin" value="" />
          {cities.map((city, index) => (
            <Picker.Item key={index} label={city.name} value={city.name} />
          ))}
        </Picker>
      </View>
      <Text style={styles.localTime}>{calculateLocalTime()}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  pickerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  icon: {
    fontSize: 24,
    color: '#888',
    marginRight: 10,
  },
  picker: {
    flex: 1,
    height: 50,
    color: '#333',
  },
  pickerItem: {
    fontSize: 16,
    color: '#333',
  },
  localTime: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#555',
  },
});

export default LocalTimeScreen;
