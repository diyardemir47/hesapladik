import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const GoldenRatioCalculator = () => {
  const [inputValue, setInputValue] = useState('');
  const [goldenRatio, setGoldenRatio] = useState('');

  const calculateGoldenRatio = () => {
    const targetRatio = 1.618033988749895; // Altın oranın tam değeri

    if (inputValue === '') {
      setGoldenRatio('Lütfen bir değer girin.');
      return;
    }

    const inputNumber = parseFloat(inputValue);

    if (isNaN(inputNumber)) {
      setGoldenRatio('Geçerli bir sayı girin.');
      return;
    }

    const result = inputNumber * targetRatio;
    setGoldenRatio(`Altın oran: ${result}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.cardText}>Altın Oran Hesaplayıcı</Text>

        <TextInput
          style={styles.input}
          placeholder="Değer girin"
          value={inputValue}
          onChangeText={text => setInputValue(text)}
          keyboardType="numeric"
        />

        <TouchableOpacity style={styles.button} onPress={calculateGoldenRatio}>
          <Text style={styles.buttonText}>Hesapla</Text>
        </TouchableOpacity>

        <Text style={styles.resultText}>{goldenRatio}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 16,
    width: '80%',
  },
  cardText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    padding: 8,
    marginBottom: 16,
  },
  button: {
    backgroundColor: '#2196f3',
    borderRadius: 4,
    padding: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  resultText: {
    marginTop: 16,
    textAlign: 'center',
  },
});

export default GoldenRatioCalculator;
