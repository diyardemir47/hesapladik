import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const GoldCalculationScreen = () => {
  const [weight, setWeight] = useState('');
  const [price, setPrice] = useState('');
  const [result, setResult] = useState('');

  const calculateGold = () => {
    const goldWeight = parseFloat(weight);
    const goldPrice = parseFloat(price);
    
    if (isNaN(goldWeight) || isNaN(goldPrice)) {
      setResult('');
    } else {
      const resultAmount = goldWeight * goldPrice;
      setResult(resultAmount.toFixed(2));
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Altın Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Ağırlık (gr)"
        keyboardType="numeric"
        value={weight}
        onChangeText={setWeight}
      />
      <TextInput
        style={styles.input}
        placeholder="Fiyat (TL/gr)"
        keyboardType="numeric"
        value={price}
        onChangeText={setPrice}
      />
      <Button title="Hesapla" onPress={calculateGold} color="#9c27b0" />
      {result !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>Sonuç</Text>
          <Text style={styles.amountText}>{result}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  resultContainer: {
    backgroundColor: '#9c27b0',
    width: '100%',
    padding: 16,
    marginTop: 20,
    borderRadius: 8,
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  amountText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default GoldCalculationScreen;
