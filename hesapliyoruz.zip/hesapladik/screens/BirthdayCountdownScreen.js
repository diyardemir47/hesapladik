import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import Card from '../components/Card';

const BirthdayCountdownScreen = () => {
  const [birthday, setBirthday] = useState('');
  const [daysLeft, setDaysLeft] = useState('');
  const [isBirthdayPickerVisible, setBirthdayPickerVisibility] = useState(false);

  const showBirthdayPicker = () => {
    setBirthdayPickerVisibility(true);
  };

  const hideBirthdayPicker = () => {
    setBirthdayPickerVisibility(false);
  };

  const handleBirthdayConfirm = date => {
    setBirthday(date.toISOString().split('T')[0]);
    hideBirthdayPicker();
  };

  const calculateDaysLeft = () => {
    const currentDate = new Date().toISOString().split('T')[0];
    const currentDateValue = new Date(currentDate);
    const birthdayValue = new Date(birthday);
    const timeDifference = birthdayValue.getTime() - currentDateValue.getTime();
    const daysLeftValue = Math.ceil(timeDifference / (1000 * 3600 * 24));
    setDaysLeft(daysLeftValue.toString());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Doğum Gününe Kaç Gün Kaldı</Text>
      <Card>
        <View style={styles.inputContainer}>
          <Text style={styles.label}>Doğum Günü:</Text>
          <Button title={birthday || 'Tarih Seç'} onPress={showBirthdayPicker} />
          <DateTimePickerModal
            isVisible={isBirthdayPickerVisible}
            mode="date"
            onConfirm={handleBirthdayConfirm}
            onCancel={hideBirthdayPicker}
          />
        </View>
        <Button title="Hesapla" onPress={calculateDaysLeft} />
        <Text style={styles.result}>{daysLeft}</Text>
      </Card>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  label: {
    marginRight: 10,
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
  },
});

export default BirthdayCountdownScreen;
