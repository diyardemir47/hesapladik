import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const LoanCalculationScreen = () => {
  const [loanAmount, setLoanAmount] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [loanTerm, setLoanTerm] = useState('');
  const [result, setResult] = useState('');

  const formatPrice = (price) => {
    if (price === '') return '';
    return price.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
  };

  const calculateLoan = () => {
    const amount = parseFloat(loanAmount.replace('.', '').replace(',', '.'));
    const rate = parseFloat(interestRate) / 100;
    const term = parseFloat(loanTerm);

    if (isNaN(amount) || isNaN(rate) || isNaN(term)) {
      setResult('');
    } else {
      const monthlyPayment = (amount * rate * Math.pow(1 + rate, term)) / (Math.pow(1 + rate, term) - 1);
      const principalPayment = amount / term;
      const interestPayment = monthlyPayment - principalPayment;

      setResult(formatPrice(monthlyPayment.toFixed(2)) + ' TL');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Kredi Hesaplama</Text>
      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Kredi Tutarı (TL)</Text>
        <TextInput
          style={styles.input}
          placeholder="0"
          keyboardType="numeric"
          value={formatPrice(loanAmount)}
          onChangeText={(value) => setLoanAmount(value.replace('.', '').replace(',', '.'))}
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Faiz Oranı (%)</Text>
        <TextInput
          style={styles.input}
          placeholder="0"
          keyboardType="numeric"
          value={interestRate}
          onChangeText={setInterestRate}
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Kredi Süresi (Ay)</Text>
        <TextInput
          style={styles.input}
          placeholder="0"
          keyboardType="numeric"
          value={loanTerm}
          onChangeText={setLoanTerm}
        />
      </View>
      <Button title="Hesapla" onPress={calculateLoan} color="#9c27b0" />
      {result !== '' && (
        <View style={styles.resultContainer}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Aylık Ödeme</Text>
            <Text style={styles.cardAmount}>{result}</Text>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 10,
    width: '100%',
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  resultContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  card: {
    width: '100%',
    padding: 20,
    borderRadius: 8,
    backgroundColor: '#fff',
    elevation: 4,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  cardAmount: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default LoanCalculationScreen;
