import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const NewYearCountdownScreen = () => {
  const [countdown, setCountdown] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    calculateCountdown();
    const countdownInterval = setInterval(calculateCountdown, 1000);

    return () => {
      clearInterval(countdownInterval);
    };
  }, []);

  const calculateCountdown = () => {
    const currentDate = new Date();
    const newYearDate = new Date(currentDate.getFullYear() + 1, 0, 1);
    const timeDifference = newYearDate - currentDate;

    if (timeDifference > 0) {
      const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);

      setCountdown({
        days,
        hours,
        minutes,
        seconds,
      });
    } else {
      setCountdown({
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0,
      });
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Yılbaşına Kalan Süre</Text>
      <View style={styles.countdownContainer}>
        <View style={styles.timeContainer}>
          <Text style={[styles.time, styles.daysText]}>{countdown.days}</Text>
          <Text style={[styles.label, styles.daysLabel]}>Gün</Text>
        </View>
        <Text style={styles.separator}>:</Text>
        <View style={styles.timeContainer}>
          <Text style={[styles.time, styles.timeText]}>{countdown.hours}</Text>
          <Text style={[styles.label, styles.timeLabel]}>Saat</Text>
        </View>
        <Text style={styles.separator}>:</Text>
        <View style={styles.timeContainer}>
          <Text style={[styles.time, styles.timeText]}>{countdown.minutes}</Text>
          <Text style={[styles.label, styles.timeLabel]}>Dakika</Text>
        </View>
        <Text style={styles.separator}>:</Text>
        <View style={styles.timeContainer}>
          <Text style={[styles.time, styles.timeText]}>{countdown.seconds}</Text>
          <Text style={[styles.label, styles.timeLabel]}>Saniye</Text>
        </View>
      </View>
      <Icon name="firework" style={styles.fireworksIcon} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  countdownContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timeContainer: {
    alignItems: 'center',
  },
  time: {
    fontSize: 48,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  daysText: {
    color: '#FF5252', // Kırmızı renk
  },
  daysLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FF5252',
    textTransform: 'uppercase',
  },
  timeText: {
    color: '#333', // Siyah renk
  },
  timeLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#777',
    textTransform: 'uppercase',
  },
  separator: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#333',
    marginHorizontal: 4,
  },
  fireworksIcon: {
    fontSize: 64,
    color: '#FFD700', // Altın sarısı renk
    marginTop: 20,
  },
});

export default NewYearCountdownScreen;
