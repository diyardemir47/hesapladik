import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';

const DaireHesaplama = () => {
  const [inputValue, setInputValue] = useState('');
  const [result, setResult] = useState('');
  const [showResult, setShowResult] = useState(false);

  const calculateCircle = () => {
    const radius = parseFloat(inputValue);

    if (isNaN(radius) || radius <= 0) {
      setResult('Geçerli bir sayı girin.');
      setShowResult(true);
      return;
    }

    const circumference = 2 * Math.PI * radius;
    const area = Math.PI * Math.pow(radius, 2);

    setResult(`Çevre: ${circumference}, Alan: ${area}`);
    setShowResult(true);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Daire Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Bir değer girin"
        placeholderTextColor="#000000"
        keyboardType="numeric"
        value={inputValue}
        onChangeText={text => setInputValue(text)}
      />
      <TouchableOpacity style={styles.button} onPress={calculateCircle}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>
      {showResult && (
        <View style={styles.resultContainer}>
         
          <View style={styles.resultCard}>
            <Text style={styles.resultText}>{result}</Text>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderWidth: 1,
    borderColor: '#000000',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
    color: '#000000',
  },
  button: {
    backgroundColor: '#6A00FF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultContainer: {
    alignItems: 'center',
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  resultCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    width: '80%',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default DaireHesaplama;
