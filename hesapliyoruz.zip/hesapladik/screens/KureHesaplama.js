// SphereCalc.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const KureHesaplama = () => {
  const [inputValue, setInputValue] = useState('');
  const [result, setResult] = useState('');

  const calculateSphere = () => {
    if (inputValue === '') {
      setResult('Lütfen bir değer girin.');
      return;
    }

    const radius = parseFloat(inputValue);

    if (isNaN(radius) || radius <= 0) {
      setResult('Geçerli bir sayı girin.');
      return;
    }

    const volume = (4 / 3) * Math.PI * Math.pow(radius, 3);
    const surfaceArea = 4 * Math.PI * Math.pow(radius, 2);

    setResult(`Hacim: ${volume}, Yüzey Alanı: ${surfaceArea}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Küre Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Bir değer girin"
        keyboardType="numeric"
        value={inputValue}
        onChangeText={text => setInputValue(text)}
      />
      <TouchableOpacity style={styles.button} onPress={calculateSphere}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>
      <Text style={styles.result}>{result}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default KureHesaplama;
