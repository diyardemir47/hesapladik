// CombCalc.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const KombinasyonHesaplama = () => {
  const [inputValue, setInputValue] = useState('');
  const [result, setResult] = useState('');

  const calculateCombination = () => {
    if (inputValue === '') {
      setResult('Lütfen bir değer girin.');
      return;
    }

    const n = parseInt(inputValue);

    if (isNaN(n) || n < 0) {
      setResult('Geçerli bir sayı girin.');
      return;
    }

    const factorialN = factorial(n);
    const factorialR = factorial(n - 2);
    const combination = factorialN / (factorialR * factorial(2));

    setResult(`Kombinasyon: ${combination}`);
  };

  const factorial = num => {
    if (num === 0 || num === 1) {
      return 1;
    } else {
      return num * factorial(num - 1);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Kombinasyon Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Bir değer girin"
        keyboardType="numeric"
        value={inputValue}
        onChangeText={text => setInputValue(text)}
      />
      <TouchableOpacity style={styles.button} onPress={calculateCombination}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>
      <Text style={styles.result}>{result}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default KombinasyonHesaplama;
