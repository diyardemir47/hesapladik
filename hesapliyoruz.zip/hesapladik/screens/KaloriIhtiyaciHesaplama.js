import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';

const DailyCalorieCalculator = () => {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [age, setAge] = useState('');
  const [calorieResult, setCalorieResult] = useState('');

  const calculateCalorieNeeds = () => {
    if (weight === '' || height === '' || age === '') {
      setCalorieResult('Lütfen kilonuzu, boyunuzu ve yaşınızı girin.');
      return;
    }

    const weightNum = parseFloat(weight);
    const heightNum = parseFloat(height);
    const ageNum = parseFloat(age);

    if (isNaN(weightNum) || isNaN(heightNum) || isNaN(ageNum) || weightNum <= 0 || heightNum <= 0 || ageNum <= 0) {
      setCalorieResult('Geçerli değerler girin.');
      return;
    }

    // Bazal Metabolik Hız (BMH) hesaplama
    const bmh = 655.1 + (9.56 * weightNum) + (1.85 * heightNum) - (4.67 * ageNum);

    // Aktivite katsayısına göre günlük kalori ihtiyacının hesaplanması
    const activityLevel = 1.4; // Orta düzeyde hareketli
    const dailyCalorieNeeds = bmh * activityLevel;

    setCalorieResult(`Günlük Kalori İhtiyacınız: ${dailyCalorieNeeds.toFixed(2)} kalori`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Günlük Kalori İhtiyacı Hesaplama</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Kilonuz (kg):</Text>
        <TextInput
          style={styles.input}
          placeholder="Kilonuzu girin"
          keyboardType="numeric"
          value={weight}
          onChangeText={(text) => setWeight(text)}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Boyunuz (cm):</Text>
        <TextInput
          style={styles.input}
          placeholder="Boyunuzu girin"
          keyboardType="numeric"
          value={height}
          onChangeText={(text) => setHeight(text)}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Yaşınız:</Text>
        <TextInput
          style={styles.input}
          placeholder="Yaşınızı girin"
          keyboardType="numeric"
          value={age}
          onChangeText={(text) => setAge(text)}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={calculateCalorieNeeds}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>

      {calorieResult !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>{calorieResult}</Text>
        </View>
      )}

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Not: Bu hesaplama sadece bir tahmindir. Kişisel ihtiyaçlarınıza göre daha kesin bir hesaplama yapmak için
          beslenme uzmanıyla görüşün.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  label: {
    flex: 1,
    fontSize: 16,
  },
  input: {
    flex: 1,
    height: 40,
    width: '100%',
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultContainer: {
    marginTop: 20,
    backgroundColor: 'lightgray',
    padding: 10,
    borderRadius: 5,
  },
  resultText: {
    fontSize: 16,
  },
  footer: {
    marginTop: 20,
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
  },
});

export default DailyCalorieCalculator;
