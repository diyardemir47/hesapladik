import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const DrivingExamScoreCalculationScreen = () => {
  const [trafficLaws, setTrafficLaws] = useState('');
  const [trafficSigns, setTrafficSigns] = useState('');
  const [firstAid, setFirstAid] = useState('');
  const [examScore, setExamScore] = useState('');

  const calculateExamScore = () => {
    const laws = parseFloat(trafficLaws);
    const signs = parseFloat(trafficSigns);
    const aid = parseFloat(firstAid);

    const totalScore = laws + signs + aid;
    setExamScore(totalScore.toString());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Ehliyet Sınavı Puan Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Trafik Kuralları Notu"
        keyboardType="numeric"
        value={trafficLaws}
        onChangeText={setTrafficLaws}
      />
      <TextInput
        style={styles.input}
        placeholder="Trafik İşaretleri Notu"
        keyboardType="numeric"
        value={trafficSigns}
        onChangeText={setTrafficSigns}
      />
      <TextInput
        style={styles.input}
        placeholder="İlk Yardım Notu"
        keyboardType="numeric"
        value={firstAid}
        onChangeText={setFirstAid}
      />
      <Button title="Hesapla" onPress={calculateExamScore} />
      <Text style={styles.resultText}>Sınav Puanı: {examScore}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  resultText: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default DrivingExamScoreCalculationScreen;
