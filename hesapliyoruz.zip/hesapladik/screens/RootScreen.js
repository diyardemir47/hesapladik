import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import Card from '../components/Card';

const RootScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Hesaplanacak Konular</Text>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Power')}
      >
        <Text style={styles.buttonText}>Üslü Sayılar Hesaplama</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Root')}
      >
        <Text style={styles.buttonText}>Köklü Sayılar Hesaplama</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Hesaplanacak Konular</Text>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('AgeCalculation')}
      >
        <Text style={styles.buttonText}>Yaş Hesaplama</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('BirthdayCountdown')}
      >
        <Text style={styles.buttonText}>Doğum Gününe Kaç Gün Kaldı</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('NewYearCountdown')}
      >
        <Text style={styles.buttonText}>Yılbaşına Kaç Gün Kaldı</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Holiday')}
      >
        <Text style={styles.buttonText}>Resmi ve Dini Bayramlar</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('DateDifference')}
      >
        <Text style={styles.buttonText}>Verilen Tarihler Arasında Kaç Gün Var</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('BmiCalculation')}
      >
        <Text style={styles.buttonText}>Boy ve Kilo ile Kitle Endeksi Hesaplama</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#e0e0e0',
    padding: 16,
    borderRadius: 8,
    marginBottom: 10,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default RootScreen;
