import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const DollarCalculationScreen = () => {
  const [amount, setAmount] = useState('');
  const [exchangeRate, setExchangeRate] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchExchangeRate();
  }, []);

  const fetchExchangeRate = async () => {
    try {
      const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
      const data = await response.json();
      const rate = data.rates['TRY'];
      setExchangeRate(rate.toFixed(2));
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const calculateDollar = () => {
    const dollarAmount = parseFloat(amount);
    const dollarRate = parseFloat(exchangeRate);
    
    if (isNaN(dollarAmount) || isNaN(dollarRate)) {
      setResult('');
    } else {
      const resultAmount = dollarAmount * dollarRate;
      setResult(resultAmount.toFixed(2));
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Dolar Hesaplama</Text>
      <TextInput
        style={styles.input}
        placeholder="Miktar"
        keyboardType="numeric"
        value={amount}
        onChangeText={setAmount}
      />
      {loading ? (
        <Text style={styles.loadingText}>Döviz Kuru Yükleniyor...</Text>
      ) : (
        <TextInput
          style={styles.input}
          placeholder="Döviz Kuru"
          keyboardType="numeric"
          value={exchangeRate}
          onChangeText={setExchangeRate}
          editable={false}
        />
      )}
      <Button title="Hesapla" onPress={calculateDollar} color="#9c27b0" />
      {result !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>Sonuç</Text>
          <Text style={styles.amountText}>{result}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  loadingText: {
    fontSize: 16,
    marginBottom: 10,
  },
  resultContainer: {
    backgroundColor: '#9c27b0',
    width: '100%',
    padding: 16,
    marginTop: 20,
    borderRadius: 8,
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  amountText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default DollarCalculationScreen;
