import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const Saglik = ({ navigation }) => {
  const handleTopicPress = (routeName) => {
    const calculation = topics
      .flatMap((category) => category.calculations)
      .find((calculation) => calculation.name === routeName);
    if (calculation && calculation.route) {
      navigation.navigate(calculation.route);
    }
  };

  const topics = [
    {
      category: '',
      calculations: [
        { name: 'Kitle Endeksi', icon: 'ios-body-outline', route: 'BmiCalculation' },
        { name: 'Günlük Su İhtiyacı', icon: 'ios-water-outline', route: 'WaterFatCalculation' },
        { name: 'Bel Kalça Oranı', icon: 'ios-resize-outline', route: 'BelKalcaOraniHesaplama' },
        { name: 'Karbonhidrat İhtiyacı', icon: 'ios-server-outline', route: 'KarbonhidratHesaplama' },
        { name: 'Kalori ihtiyacı', icon: 'ios-nutrition-outline', route: 'KaloriIhtiyaciHesaplama' },
        { name: 'Yağ Yakma Nabız Aralığı ', icon: 'ios-flame-outline', route: 'YagYakmaHiziHesaplama' },
      ],
    },
  ];

  return (
    <View style={styles.container}>
      {topics.map((category) => (
        <View key={category.category} style={styles.categoryContainer}>
          <Text style={styles.categoryTitle}>{category.category}</Text>
          {category.calculations.map((calculation) => (
            <TouchableOpacity
              key={calculation.name}
              style={styles.button}
              onPress={() => handleTopicPress(calculation.name)}
            >
              <Ionicons name={calculation.icon} size={32} color="#6A00FF" />
              <Text style={styles.buttonText}>{calculation.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  categoryContainer: {
    marginBottom: 20,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginBottom: 10,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    elevation: 3,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
});

export default Saglik;
