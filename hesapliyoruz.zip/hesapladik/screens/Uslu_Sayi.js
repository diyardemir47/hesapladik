import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { TextInput, IconButton } from "@react-native-material/core";
import Icon from "@expo/vector-icons/MaterialCommunityIcons";

const PowerScreen = () => {
  const [base, setBase] = useState('');
  const [exponent, setExponent] = useState('');
  const [result, setResult] = useState('');

  const calculatePower = () => {
    const baseNumber = parseFloat(base);
    const exponentNumber = parseFloat(exponent);
    const powerResult = Math.pow(baseNumber, exponentNumber);
    setResult(powerResult.toString());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Üslü Sayı Hesaplama</Text>
      <View style={[styles.inputContainer, { justifyContent: 'center' }]}>
        <Text style={styles.inputLabel}></Text>
        <TextInput
          label="Taban"
          variant="outlined"
          style={styles.input}
          value={base}
          onChangeText={(text) => setBase(text)}
          keyboardType="numeric"
          trailing={(props) => (
            <IconButton icon={(props) => <Icon name="math-compass" {...props} />} {...props} />
          )}
        />
      </View>
      <View style={[styles.inputContainer, { justifyContent: 'center' }]}>
        <Text style={styles.inputLabel}></Text>
        <TextInput
          label="Üs"
          variant="outlined"
          style={styles.input}
          value={exponent}
          onChangeText={(text) => setExponent(text)}
          keyboardType="numeric"
          trailing={(props) => (
            <IconButton icon={(props) => <Icon name="math-norm" {...props} />} {...props} />
          )}
        />
      </View>
      <TouchableOpacity style={[styles.button, { marginTop: 20, marginBottom: 10 }]} onPress={calculatePower}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>
      {result !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>{result}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin:10,
    justifyContent:'center',
    left:-20,
  },
  inputLabel: {
    width: 80,
    fontSize: 16,
  },
  input: {
    flex: 1,
    height: 40,
    paddingHorizontal: 10,
    marginRight: 10,
  },
  button: {
    backgroundColor: '#9c27b0',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  resultContainer: {
    width: '100%',
    padding: 16,
    marginTop: 20,
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default PowerScreen;
