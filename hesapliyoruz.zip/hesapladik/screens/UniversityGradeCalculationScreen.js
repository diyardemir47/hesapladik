import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const UniversityGradeCalculationScreen = () => {
  const [midtermGrade, setMidtermGrade] = useState('');
  const [finalGrade, setFinalGrade] = useState('');
  const [average, setAverage] = useState('');
  const [midtermWeight, setMidtermWeight] = useState(40);
  const [finalWeight, setFinalWeight] = useState(60);

  const calculateAverage = () => {
    const midterm = parseFloat(midtermGrade);
    const final = parseFloat(finalGrade);
    const midtermWeightage = midtermWeight / 100;
    const finalWeightage = finalWeight / 100;

    const averageScore = (midterm * midtermWeightage) + (final * finalWeightage);
    setAverage(averageScore.toString());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Üniversite Vize Final Ortalama Hesaplama</Text>
      <View style={styles.inputContainer}>
        <Ionicons name="ios-calculator-outline" size={24} color="#6A00FF" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Vize Notu"
          keyboardType="numeric"
          value={midtermGrade}
          onChangeText={setMidtermGrade}
        />
      </View>
      <View style={styles.inputContainer}>
        <Ionicons name="ios-calculator-outline" size={24} color="#6A00FF" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Final Notu"
          keyboardType="numeric"
          value={finalGrade}
          onChangeText={setFinalGrade}
        />
      </View>
      <View style={styles.inputContainer}>
        <Ionicons name="ios-cog" size={24} color="#6A00FF" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Vize Ağırlığı (%)"
          keyboardType="numeric"
          value={midtermWeight.toString()}
          onChangeText={(value) => setMidtermWeight(parseFloat(value))}
        />
      </View>
      <View style={styles.inputContainer}>
        <Ionicons name="ios-cog" size={24} color="#6A00FF" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Final Ağırlığı (%)"
          keyboardType="numeric"
          value={finalWeight.toString()}
          onChangeText={(value) => setFinalWeight(parseFloat(value))}
        />
      </View>
      <TouchableOpacity style={styles.button} onPress={calculateAverage}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>
      <Text style={styles.resultText}>Ortalama: {average}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  icon: {
    marginRight: 10,
  },
  button: {
    backgroundColor: '#6A00FF',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginTop: 10,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  resultText: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default UniversityGradeCalculationScreen;
