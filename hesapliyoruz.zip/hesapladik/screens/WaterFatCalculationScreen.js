import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const WaterFatCalculationScreen = () => {
  const [weight, setWeight] = useState('');
  const [waterResult, setWaterResult] = useState('');
  const [fatResult, setFatResult] = useState('');

  const calculateWaterAndFat = () => {
    const weightValue = parseFloat(weight);

    if (!isNaN(weightValue)) {
      // Su ihtiyacı hesaplama: Kilo x 30 ml
      const waterNeed = weightValue * 30;

      // Yağ ihtiyacı hesaplama: Günlük kalori miktarının yüzde 30'u
      const dailyCalorieIntake = weightValue * 30; // Örnek olarak kilo x 30 olarak kabul ediyoruz
      const fatIntake = dailyCalorieIntake * 0.3;

      setWaterResult(waterNeed.toString());
      setFatResult(fatIntake.toString());
    } else {
      setWaterResult('');
      setFatResult('');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Günlük Su ve Yağ İhtiyacı Hesaplama</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Kilo"
          keyboardType="numeric"
          value={weight}
          onChangeText={setWeight}
        />
        <FontAwesome name="balance-scale" size={20} color="#2196F3" style={styles.icon} />
      </View>
      <TouchableOpacity style={styles.calculateButton} onPress={calculateWaterAndFat}>
        <Text style={styles.calculateButtonText}>Hesapla</Text>
      </TouchableOpacity>
      {waterResult !== '' && (
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>Günlük Su İhtiyacı:</Text>
          <Text style={styles.resultValue}>{waterResult} ml</Text>
        </View>
      )}
      {fatResult !== '' && (
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>Günlük Yağ İhtiyacı:</Text>
          <Text style={styles.resultValue}>{fatResult} gram</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
    marginRight: 10,
  },
  icon: {
    marginRight: 10,
  },
  calculateButton: {
    backgroundColor: '#9c27b0',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 20,
  },
  calculateButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  resultCard: {
    backgroundColor: '#f3f3f3',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginBottom: 10,
    width: '100%',
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  resultValue: {
    fontSize: 18,
  },
});

export default WaterFatCalculationScreen;
