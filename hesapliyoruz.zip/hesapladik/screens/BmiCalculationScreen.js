import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const BmiCalculationScreen = () => {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [bmi, setBmi] = useState(null);
  const [resultColor, setResultColor] = useState('#000000');

  const calculateBMI = () => {
    if (height && weight) {
      const heightInMeters = parseFloat(height) / 100;
      const weightInKg = parseFloat(weight);
      const bmiResult = weightInKg / (heightInMeters * heightInMeters);
      setBmi(bmiResult.toFixed(2));

      if (bmiResult < 18.5) {
        setResultColor('#FF0000'); // Kırmızı
      } else if (bmiResult >= 18.5 && bmiResult <= 24.9) {
        setResultColor('#00FF00'); // Yeşil
      } else if (bmiResult >= 25.0 && bmiResult <= 29.9) {
        setResultColor('#FFA500'); // Turuncu
      } else if (bmiResult >= 30.0 && bmiResult <= 34.9) {
        setResultColor('#0000FF'); // Mavi
      } else if (bmiResult >= 35.0 && bmiResult <= 39.9) {
        setResultColor('#0000FF'); // Mavi
      } else {
        setResultColor('#FFA500'); // Turuncu
      }
    } else {
      setBmi(null);
    }
  };

  const getResultText = () => {
    if (bmi !== null) {
      if (bmi < 18.5) {
        return 'Zayıf';
      } else if (bmi >= 18.5 && bmi <= 24.9) {
        return 'Normal ağırlıkta';
      } else if (bmi >= 25.0 && bmi <= 29.9) {
        return 'Kilolu';
      } else if (bmi >= 30.0 && bmi <= 34.9) {
        return '1. derece obezite';
      } else if (bmi >= 35.0 && bmi <= 39.9) {
        return '2. derece obezite';
      } else {
        return '3. derece obezite';
      }
    } else {
      return '';
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Boy ve Kilo ile Kitle Endeksi Hesaplama</Text>
      <View style={styles.inputContainer}>
        <MaterialIcons name="person" size={24} color="#757575" style={styles.icon} />
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          placeholder="Boy (cm)"
          value={height}
          onChangeText={(text) => setHeight(text)}
        />
      </View>
      <View style={styles.inputContainer}>
        <MaterialIcons name="fitness-center" size={24} color="#757575" style={styles.icon} />
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          placeholder="Kilo (kg)"
          value={weight}
          onChangeText={(text) => setWeight(text)}
        />
      </View>
      <TouchableOpacity style={[styles.calculateButton, { backgroundColor: '#6A00FF' }]} onPress={calculateBMI}>
        <Text style={styles.calculateButtonText}>Hesapla</Text>
      </TouchableOpacity>
      {bmi !== null && (
        <View style={[styles.resultContainer, { backgroundColor: resultColor }]}>
          <Text style={styles.resultText}>Vücut Kitle İndeksi (BMI): {bmi}</Text>
          <Text style={styles.resultDescription}>{getResultText()}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    backgroundColor: '#e0e0e0',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 10,
    width: '80%',
  },
  calculateButton: {
    backgroundColor: '#6A00FF',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginTop: 10,
    width: '80%',
  },
  calculateButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  resultContainer: {
    marginTop: 20,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    width: '80%',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
  },
  resultDescription: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
});

export default BmiCalculationScreen;
