import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';

const KarbonhidratHesaplama = () => {
  const [kilo, setKilo] = useState('');
  const [aktiviteSeviyesi, setAktiviteSeviyesi] = useState('');
  const [karbonhidratIhtiyaci, setKarbonhidratIhtiyaci] = useState('');

  const calculateKarbonhidratIhtiyaci = () => {
    if (kilo === '' || aktiviteSeviyesi === '') {
      setKarbonhidratIhtiyaci('Lütfen kilonuzu ve aktivite seviyenizi girin.');
      return;
    }

    const kiloNum = parseFloat(kilo);
    const aktiviteSeviyesiNum = parseFloat(aktiviteSeviyesi);

    if (isNaN(kiloNum) || isNaN(aktiviteSeviyesiNum) || kiloNum <= 0 || aktiviteSeviyesiNum <= 0) {
      setKarbonhidratIhtiyaci('Geçerli değerler girin.');
      return;
    }

    const karbonhidratIhtiyaciNum = kiloNum * aktiviteSeviyesiNum * 4; // Her gram karbonhidrat için 4 kalori

    setKarbonhidratIhtiyaci(`Günlük Karbonhidrat İhtiyacınız: ${karbonhidratIhtiyaciNum.toFixed(2)} kalori`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Günlük Karbonhidrat İhtiyacı Hesaplama</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Kilonuz (kg):</Text>
        <TextInput
          style={styles.input}
          placeholder="Kilonuzu girin"
          keyboardType="numeric"
          value={kilo}
          onChangeText={(text) => setKilo(text)}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Aktivite Seviyeniz:</Text>
        <TextInput
          style={styles.input}
          placeholder="Aktivite seviyenizi girin"
          keyboardType="numeric"
          value={aktiviteSeviyesi}
          onChangeText={(text) => setAktiviteSeviyesi(text)}
        />
        <Text style={styles.inputDescription}>
          Aktivite Seviyesi: {'\n'}
          1. Oturarak çalışanlar ve egzersiz yapmayanlar {'\n'}
          2. Hafif aktivite yapanlar (hafif egzersiz veya yürüyüş) {'\n'}
          3. Orta seviye aktivite yapanlar (haftada 3-4 kez spor) {'\n'}
          4. Yüksek seviye aktivite yapanlar (haftada 5-7 kez spor) {'\n'}
          5. Profesyonel sporcular veya ağır fiziksel aktivite yapanlar
        </Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={calculateKarbonhidratIhtiyaci}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>

      {karbonhidratIhtiyaci !== '' && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>{karbonhidratIhtiyaci}</Text>
        </View>
      )}

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Not: Bu örnek sadece bir temel örnektir. Gerçek hayatta karbonhidrat ihtiyacı hesaplama daha karmaşık faktörlere dayanabilir ve diyetisyenin önerileri göz önünde bulundurulmalıdır.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  inputDescription: {
    fontSize: 12,
    marginBottom: 10,
    color: '#888',
  },
  button: {
    backgroundColor: '#6A00FF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 20,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#6A00FF',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  footer: {
    marginTop: 20,
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
    color: '#888',
  },
});

export default KarbonhidratHesaplama;
