import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';

const BelKalcaOraniHesaplama = () => {
  const [belOlcu, setBelOlcu] = useState('');
  const [kalcaOlcu, setKalcaOlcu] = useState('');
  const [oran, setOran] = useState('');
  const [durum, setDurum] = useState('');

  const calculateRatio = () => {
    if (belOlcu === '' || kalcaOlcu === '') {
      setOran('Lütfen ölçüleri girin.');
      setDurum('');
      return;
    }

    const bel = parseFloat(belOlcu);
    const kalca = parseFloat(kalcaOlcu);

    if (isNaN(bel) || isNaN(kalca) || bel <= 0 || kalca <= 0) {
      setOran('Geçerli ölçüler girin.');
      setDurum('');
      return;
    }

    const oran = bel / kalca;

    setOran(`Oran: ${oran.toFixed(2)}`);

    if (belOlcu < kalcaOlcu) {
      if (oran <= 0.8) {
        setDurum('Düşük düzeyde sağlık riski');
      } else if (oran >= 0.81 && oran <= 0.84) {
        setDurum('Orta düzeyde sağlık riski');
      } else {
        setDurum('Yüksek düzeyde sağlık riski');
      }
    } else {
      if (oran <= 0.95) {
        setDurum('Düşük düzeyde sağlık riski');
      } else if (oran >= 0.96 && oran <= 1.0) {
        setDurum('Orta düzeyde sağlık riski');
      } else {
        setDurum('Yüksek düzeyde sağlık riski');
      }
    }
  };

  const getDurumColor = () => {
    if (durum === 'Düşük düzeyde sağlık riski') {
      return '#00FF00'; // Yeşil
    } else if (durum === 'Orta düzeyde sağlık riski') {
      return '#CDDC39'; // Sarı
    } else {
      return '#FF0000'; // Kırmızı
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bel-Kalça Oranı Hesaplama</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Bel Ölçüsü (cm):</Text>
        <TextInput
          style={styles.input}
          placeholder="Bel ölçüsünü girin"
          keyboardType="numeric"
          value={belOlcu}
          onChangeText={(text) => setBelOlcu(text)}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Kalça Ölçüsü (cm):</Text>
        <TextInput
          style={styles.input}
          placeholder="Kalça ölçüsünü girin"
          keyboardType="numeric"
          value={kalcaOlcu}
          onChangeText={(text) => setKalcaOlcu(text)}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={calculateRatio}>
        <Text style={styles.buttonText}>Hesapla</Text>
      </TouchableOpacity>

      {oran !== '' && durum !== '' && (
        <View style={[styles.resultContainer, { backgroundColor: getDurumColor() }]}>
          <Text style={styles.resultText}>{oran}</Text>
          <Text style={styles.resultText}>{durum}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 5,
  },
  input: {
    width: 200,
    height: 40,
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: '#6A00FF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 20,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
});

export default BelKalcaOraniHesaplama;
