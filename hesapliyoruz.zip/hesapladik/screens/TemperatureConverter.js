import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput } from 'react-native';

const TemperatureConverter = () => {
  const [celsius, setCelsius] = useState('');
  const [fahrenheit, setFahrenheit] = useState('');
  const [kelvin, setKelvin] = useState('');
  const [rankine, setRankine] = useState('');
  const [reaumur, setReaumur] = useState('');

  const convertCelsius = (value) => {
    setCelsius(value);
    setFahrenheit((parseFloat(value) * 9/5) + 32);
    setKelvin(parseFloat(value) + 273.15);
    setRankine((parseFloat(value) + 273.15) * 9/5);
    setReaumur(parseFloat(value) * 4/5);
  };

  const convertFahrenheit = (value) => {
    setFahrenheit(value);
    setCelsius((parseFloat(value) - 32) * 5/9);
    setKelvin((parseFloat(value) - 32) * 5/9 + 273.15);
    setRankine(parseFloat(value) + 459.67);
    setReaumur((parseFloat(value) - 32) * 4/9);
  };

  const convertKelvin = (value) => {
    setKelvin(value);
    setCelsius(parseFloat(value) - 273.15);
    setFahrenheit((parseFloat(value) - 273.15) * 9/5 + 32);
    setRankine(parseFloat(value) * 9/5);
    setReaumur((parseFloat(value) - 273.15) * 4/5);
  };

  const convertRankine = (value) => {
    setRankine(value);
    setCelsius((parseFloat(value) - 491.67) * 5/9);
    setFahrenheit(parseFloat(value) - 459.67);
    setKelvin(parseFloat(value) * 5/9);
    setReaumur((parseFloat(value) - 491.67) * 5/9 * 4/5);
  };

  const convertReaumur = (value) => {
    setReaumur(value);
    setCelsius(parseFloat(value) * 5/4);
    setFahrenheit(parseFloat(value) * 9/4 + 32);
    setKelvin(parseFloat(value) * 5/4 + 273.15);
    setRankine(parseFloat(value) * 9/4 * 9/5 + 491.67);
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Celsius</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={celsius}
          onChangeText={(value) => convertCelsius(value)}
        />
      </View>
      <View style={styles.card}>
        <Text style={styles.title}>Fahrenheit</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={fahrenheit}
          onChangeText={(value) => convertFahrenheit(value)}
        />
      </View>
      <View style={styles.card}>
        <Text style={styles.title}>Kelvin</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={kelvin}
          onChangeText={(value) => convertKelvin(value)}
        />
      </View>
      <View style={styles.card}>
        <Text style={styles.title}>Rankine</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={rankine}
          onChangeText={(value) => convertRankine(value)}
        />
      </View>
      <View style={styles.card}>
        <Text style={styles.title}>Reaumur</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={reaumur}
          onChangeText={(value) => convertReaumur(value)}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    padding: 8,
    fontSize: 16,
  },
});

export default TemperatureConverter;
