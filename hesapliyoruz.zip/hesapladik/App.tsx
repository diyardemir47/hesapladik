import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, StyleSheet, StatusBar } from 'react-native';

import HomeScreen from './screens/HomeScreen';
import CalculationScreen from './screens/CalculationScreen';

import Uslu_Sayi from './screens/Uslu_Sayi';
import RootCalculationScreen from './screens/RootCalculationScreen';
import AgeCalculationScreen from './screens/AgeCalculationScreen';
import BirthdayCountdownScreen from './screens/BirthdayCountdownScreen';
import NewYearCountdownScreen from './screens/NewYearCountdownScreen';
import HolidayScreen from './screens/HolidayScreen';
import DateDifferenceScreen from './screens/DateDifferenceScreen';
import BmiCalculationScreen from './screens/BmiCalculationScreen';
import CreditCalculationScreen from './screens/CreditCalculationScreen';
import GoldCalculationScreen from './screens/GoldCalculationScreen';
import DollarCalculationScreen from './screens/DollarCalculationScreen';
import WaterFatCalculationScreen from './screens/WaterFatCalculationScreen';
import UniversityGradeCalculationScreen from './screens/UniversityGradeCalculationScreen';
import Takdir_Tesekkur from './screens/Takdir_Tesekkur';
import FactorialCalculationScreen from './screens/FactorialCalculationScreen';
import VolumeCalculationScreen from './screens/VolumeCalculationScreen';
import Saglik from './screens/Saglik';
import Matematik from './screens/Matematik';
import Egitim from './screens/Egitim';
import Zaman from './screens/Zaman';
import AltinOranHesaplama from './screens/AltinOranHesaplama';
import BelKalcaOraniHesaplama from './screens/BelKalcaOraniHesaplama';

import KombinasyonHesaplama from './screens/KombinasyonHesaplama';
import MetrekareHesaplama from './screens/MetrekareHesaplama';
import StandartSapmaHesaplama from './screens/StandartSapmaHesaplama';
import DaireHesaplama from './screens/DaireHesaplama';
import KupHesaplama from './screens/KupHesaplama';
import KureHesaplama from './screens/KureHesaplama';
import KarbonhidratHesaplama from './screens/KarbonhidratHesaplama';
import KaloriIhtiyaciHesaplama from './screens/KaloriIhtiyaciHesaplama';
import YagYakmaHiziHesaplama from './screens/YagYakmaHiziHesaplama';
import EnflasyonHesaplama from './screens/EnflasyonHesaplama';
import Finans from './screens/Finans';
import YerelSaat from './screens/YerelSaat';
import KpssPuanHesaplama from './screens/KpssPuanHesaplama';

const Stack = createStackNavigator();

const App = () => {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Home"
          screenOptions={{
            headerStyle: { backgroundColor: '#6A00FF' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: 'bold' },
          }}
        >
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Calculation" component={CalculationScreen} />

          <Stack.Screen name="Uslu_Sayi" component={Uslu_Sayi} />
          <Stack.Screen
            name="RootCalculation"
            component={RootCalculationScreen}
            options={{ headerTitle: 'Kök Hesaplama' }}
          />
          <Stack.Screen
            name="AltinOranHesaplama"
            component={AltinOranHesaplama}
            options={{ headerTitle: 'Altın Oran Hesaplama' }}
          />
          <Stack.Screen
            name="UniversityGradeCalculationScreen"
            component={UniversityGradeCalculationScreen}
            options={{ headerTitle: 'Üniversite Not Ortalaması Hesaplama' }}
          />
          <Stack.Screen
            name="Saglik"
            component={Saglik}
            options={{ headerTitle: 'Sağlık' }}
          />
          <Stack.Screen
            name="Matematik"
            component={Matematik}
            options={{ headerTitle: 'Matematik' }}
          />
          <Stack.Screen
            name="Zaman"
            component={Zaman}
            options={{ headerTitle: 'Zaman' }}
          />
          <Stack.Screen
            name="Egitim"
            component={Egitim}
            options={{ headerTitle: 'Eğitim' }}
          />
          <Stack.Screen
            name="Takdir_Tesekkur"
            component={Takdir_Tesekkur}
            options={{ headerTitle: 'Takdir ve Teşekkür Hesaplama' }}
          />
          <Stack.Screen
            name="FactorialCalculation"
            component={FactorialCalculationScreen}
            options={{ headerTitle: 'Faktöriyel Hesaplama' }}
          />
          <Stack.Screen
            name="VolumeCalculation"
            component={VolumeCalculationScreen}
            options={{ headerTitle: 'Hacim Hesaplama' }}
          />
          <Stack.Screen
            name="AgeCalculation"
            component={AgeCalculationScreen}
            options={{ headerTitle: 'Yaş Hesaplama' }}
          />
          <Stack.Screen
            name="BirthdayCountdown"
            component={BirthdayCountdownScreen}
            options={{ headerTitle: 'Doğum Günü Geri Sayımı' }}
          />
          <Stack.Screen
            name="NewYearCountdown"
            component={NewYearCountdownScreen}
            options={{ headerTitle: 'Yılbaşı Geri Sayımı' }}
          />
          <Stack.Screen
            name="Holiday"
            component={HolidayScreen}
            options={{ headerTitle: 'Tatil Hesaplama' }}
          />
          <Stack.Screen
            name="DateDifference"
            component={DateDifferenceScreen}
            options={{ headerTitle: 'Tarih Farkı Hesaplama' }}
          />
          <Stack.Screen
            name="BmiCalculation"
            component={BmiCalculationScreen}
            options={{ headerTitle: 'Vücut Kitle İndeksi Hesaplama' }}
          />
          <Stack.Screen
            name="CreditCalculation"
            component={CreditCalculationScreen}
            options={{ headerTitle: 'Kredi Hesaplama' }}
          />
          <Stack.Screen
            name="GoldCalculation"
            component={GoldCalculationScreen}
            options={{ headerTitle: 'Altın Hesaplama' }}
          />
          <Stack.Screen
            name="DollarCalculation"
            component={DollarCalculationScreen}
            options={{ headerTitle: 'Dolar Hesaplama' }}
          />
          <Stack.Screen
            name="WaterFatCalculation"
            component={WaterFatCalculationScreen}
            options={{ headerTitle: 'Su ve Yağ Hesaplama' }}
          />
          <Stack.Screen
            name="KombinasyonHesaplama"
            component={KombinasyonHesaplama}
            options={{ headerTitle: 'Kombinasyon Hesaplama' }}
          />
          <Stack.Screen
            name="MetrekareHesaplama"
            component={MetrekareHesaplama}
            options={{ headerTitle: 'Metrekare Hesaplama' }}
          />
          <Stack.Screen
            name="StandartSapmaHesaplama"
            component={StandartSapmaHesaplama}
            options={{ headerTitle: 'Standart Sapma Hesaplama' }}
          />
          <Stack.Screen
            name="DaireHesaplama"
            component={DaireHesaplama}
            options={{ headerTitle: 'Daire Hesaplama' }}
          />
          <Stack.Screen
            name="KupHesaplama"
            component={KupHesaplama}
            options={{ headerTitle: 'Küp Hesaplama' }}
          />
          <Stack.Screen
            name="KureHesaplama"
            component={KureHesaplama}
            options={{ headerTitle: 'Küre Hesaplama' }}
          />
          <Stack.Screen
            name="BelKalcaOraniHesaplama"
            component={BelKalcaOraniHesaplama}
            options={{ headerTitle: 'Bel-Kalça Oranı Hesaplama' }}
          />
          <Stack.Screen
            name="KarbonhidratHesaplama"
            component={KarbonhidratHesaplama}
            options={{ headerTitle: 'Karbonhidrat Hesaplama' }}
          />
          <Stack.Screen
            name="KaloriIhtiyaciHesaplama"
            component={KaloriIhtiyaciHesaplama}
            options={{ headerTitle: 'Kalori İhtiyacı Hesaplama' }}
          />
          <Stack.Screen
            name="YagYakmaHiziHesaplama"
            component={YagYakmaHiziHesaplama}
            options={{ headerTitle: 'Yağ Yakma Hızı Hesaplama' }}
          />
          <Stack.Screen
            name="EnflasyonHesaplama"
            component={EnflasyonHesaplama}
            options={{ headerTitle: 'Enflasyon Hesaplama' }}
          />
          <Stack.Screen
            name="Finans"
            component={Finans}
            options={{ headerTitle: 'Finans' }}
          />
          <Stack.Screen
            name="YerelSaat"
            component={YerelSaat}
            options={{ headerTitle: 'Yerel Saat' }}
          />
          <Stack.Screen
            name="KpssPuanHesaplama"
            component={KpssPuanHesaplama}
            options={{ headerTitle: 'KPSS Puan Hesaplama' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#6A00FF',
  },
});

export default App;
